package ru.banksoyuz.dms;

import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DelinquencyTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(DelinquencyTest.class.getName());

    @Test
    public void countExternal() {
        Delinquency dlq = new Delinquency();
        String pmt = "1X1155554422155555542A11113AA111111111111111111A111111X111111X11111111111X";
        Date openDate = new GregorianCalendar(2013, Calendar.MARCH, 5).getTime();
        Date pmtStringStart = new GregorianCalendar(2019, Calendar.OCTOBER, 7).getTime();
        Date applicationDt = new GregorianCalendar(2019, Calendar.OCTOBER, 16).getTime();
        Date factCloseDate = new GregorianCalendar(2013, Calendar.MARCH, 5).getTime();
        int delqCnt = dlq.countExternal(90, 60, 112233, pmt, openDate, pmtStringStart, applicationDt, factCloseDate);
        Assert.assertEquals(17, delqCnt);
    }

}
