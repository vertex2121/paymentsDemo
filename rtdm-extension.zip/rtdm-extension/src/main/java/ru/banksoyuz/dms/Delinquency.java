package ru.banksoyuz.dms;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Calendar;
import java.util.Date;

public class Delinquency {

    private static final Logger LOGGER = LoggerFactory.getLogger(Delinquency.class.getName());

    public Delinquency() {
    }

    /*Дата начала строки (pmtStringStart) - это дата последней записи в pmtString с информацией о данном кредите
        X - Нет данных
        0 - Новый, оценка не возможна
        1 - Оплата без просрочек
        А - Просрочка от 1 до 29 дней
        2 - Просрочка от 30 до 59 дней
        3 - Просрочка от 60 до 89 дней
        4 - Просрочка от 90 до 119 дней
        5 - Просрочка более 120 дней
        7 - Изменения/дополнения к договору займа (кредита)
        8 - Погашение за счет обеспечения
        9 - Безнадежный долг/передано на взыскание*/
    public int countExternal(int daysInDelq, int termInMonth, int runId, String pmtString,
                             Date openDate, Date pmtStringStart, Date applicationDt, Date factCloseDate) {

        //Задаем формат для даты лога
        LOGGER.info("METHOD countDlqExtCreditHistory START CALC. RUN_ID: " + runId
                + " PMT_STRING_START: " + pmtStringStart + ";"
                + " Open_date: " + openDate + ";"
                + " ApplicationDt: " + applicationDt + ";"
                + " factCloseDate: " + factCloseDate + ";"
        );

        int result = 0;
        //Сохраняем значение запрошенного срока в месяцах для логирования
        int termInMonthReq = termInMonth;

        //Если applicationDt пришла пустая, возвращаем ошибку
        if (applicationDt == null || (pmtStringStart == null && openDate == null)) {
            LOGGER.info("METHOD countDlqExtCreditHistory ERR NullPointerIntoDate. RUN_ID: " + runId);
            return 404;
        }
        //Если pmtStringStart пустая, то считаем дату начала pmtStringStart = дате открытия договора
        if (pmtStringStart == null) {
            pmtStringStart = openDate;
        }

        //К pmtString добавляем неинформативную ячейку, чтобы исключить ошибку обработки когда pmtStringStart начинается с просрочки
        pmtString = pmtString + "X";

        //Если запрошенный срок больше длины pmtString, то считаем, что запросили срок = временному промежутку хранящемуся в pmtString
        if (termInMonth > pmtString.length()) {
            termInMonth = pmtString.length();
        }

        //Определяем разницу между датой начала строки и датой расчета заявки
        int differenceBetweenDatesInMonth = getDifferenceBetweenDatesInMonth(pmtStringStart, applicationDt);

        //cntDayDelay - количество дней непрекращающейся просрочки
        //fullCntDayDelay - общее количество дней просрочки для логирования
        //cntDayDelay - количество дней непрекращающейся просрочки
        int cntDayDelay = 0, fullCntDayDelay = 0, cntDayDelq = 0;
        char[] ch = pmtString.toCharArray();
        char inf = 'X';
        if (differenceBetweenDatesInMonth >= 0) {
            if (differenceBetweenDatesInMonth > 0 && factCloseDate == null) {
                for (int i = 0; i < differenceBetweenDatesInMonth; i++) {
                    inf = ch[0];
                    if (inf == ('А')) {
                        cntDayDelq += 29;
                    } else if (inf == ('2')) {
                        cntDayDelq += 59;
                    } else if (inf == ('3')) {
                        cntDayDelq += 89;
                    } else if (inf == ('4')) {
                        cntDayDelq += 119;
                    } else if (inf == ('5')) {
                        cntDayDelq += 120;
                    }
                    //System.out.println("differenceBetweenDatesInMonth: i = " + i + " ch[0] = " + ch[0] + " cntDayDelq = " + cntDayDelq + " cntDayDelay = " + cntDayDelay);
                }
                termInMonth = termInMonth - differenceBetweenDatesInMonth;
                cntDayDelay += cntDayDelq;
                fullCntDayDelay += cntDayDelq;
            }
            //Проверяем каждый месяц в PMT_STRING
            cntDayDelq = 0;
            char buff = 'X';
            inf = 'X';
            for (int i = 0; i < termInMonth; i++) {
                inf = ch[i];
                //Сохраняем последнее значение не 'X' в buff
                if (inf != ('X')) {
                    buff = inf;
                }
                //Пока нет информации о статусе кредита, считаем, что статус сохраняет последнее известное значение
                if (i > 0 && inf == ('X')) {
                    inf = buff;
                }
                if (inf == ('А')) {
                    //Здесь и ниже, условие 'inf != ch[i + 1]' нужно чтобы повторяющиеся статусы кредита не считались
                    if (inf != ch[i + 1]) {
                        cntDayDelq += 29;
                    }
                } else if (inf == ('2')) {
                    if (inf != ch[i + 1]) {
                        cntDayDelq += 59;
                    }
                } else if (inf == ('3')) {
                    if (inf != ch[i + 1]) {
                        cntDayDelq += 89;
                    }
                } else if (inf == ('4')) {
                    if (inf != ch[i + 1]) {
                        cntDayDelq += 119;
                    }
                } else if (inf == ('5')) {
                    cntDayDelq += 120;
                    //Если не получен статус просрочки, то записываем сравниваем общее количество дней этого отрезка просрочки с запрошенным
                } else {
                    if (cntDayDelq >= daysInDelq) {
                        cntDayDelay += cntDayDelq;
                    }
                    fullCntDayDelay = cntDayDelq;
                    cntDayDelq = 0;
                }
                //System.out.println("i = " + i + " ch[i] = " + ch[i] + " cntDayDelq = " + cntDayDelq + " cntDayDelay = " + cntDayDelay);
            }
            //Получаем целочисленный результат "Сколько раз запрошенное количество дней просрочки было получено за запрошенный период"
            result = cntDayDelay / daysInDelq;
        }

        LOGGER.info("METHOD countDlqExtCreditHistory FIN CALC. RUN_ID: " + runId + ";"
                + " PMT_STRING84_M: " + pmtString + ";"
                + " PMT_STRING84_M.length(): " + (pmtString.length() - 1) + ";"
                + " Request_Term_in_Month: " + termInMonthReq + ";"
                + " DifF_between_applicationDt_and_PMT_STRING_START_dt_in_month: " + differenceBetweenDatesInMonth + ";"
                + " Full_cnt_day_delay: " + fullCntDayDelay + ";"
                + " Result_cnt_delay: " + result + ";");
        return result;
    }

    private int getDifferenceBetweenDatesInMonth(Date dateStart, Date applicationDt) {
        Calendar startCalendar = Calendar.getInstance();
        Calendar endCalendar = Calendar.getInstance();

        startCalendar.setTime(dateStart);
        endCalendar.setTime(applicationDt);

        int months = 0;
        //int days = 0;

        months += ((endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR)) * 12);

        int startDays = startCalendar.get(Calendar.DAY_OF_MONTH);
        int endDays = endCalendar.get(Calendar.DAY_OF_MONTH);

        if (endDays >= startDays) {
            months += (endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH));
            //days   += (endDays - startDays);
        } else {
            months += (endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH) - 1);
            //days   += ((startCalendar.getActualMaximum(Calendar.DAY_OF_MONTH) - startDays) + endDays);
        }
        return months;
    }

}